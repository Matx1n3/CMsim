# CMsim
This is a proyect for the Computer Architecture subject in which I've developed a cache memory simulator using java.

The .jar file is stored in "/out/artifacts/CMsimulator_jar" so, if you simply wish to execute the simulator, go to this path and execute "java -jar CMsimulator.jar"

The simulator is pretty straightfoward so I don't consider that any instructions are needed.

IMPORTANT!: The simulator has been programed suposing that the user inputs will be correct, if an unexpected value is written, the program will likely crash. 
